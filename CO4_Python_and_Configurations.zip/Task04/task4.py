import math
print(f"Pure ALOHA: {100/(2*math.e):.2f}%")
print(f"Slotted ALOHA: {100/math.e:.2f}%")
t = 2*2500/2e8
bits = 10e6*t
print(f"Round trip: {t*1e6:.1f} us")
print(f"Minimum: {bits:.0f} bits, {math.ceil(bits/8)} bytes")
print(f"ATM overhead: {100*5/53:.2f}%")
print(f"Ethernet overhead: {100*18/1518:.2f}%")
print("AP channels: 1,6,11,1,6,11")
