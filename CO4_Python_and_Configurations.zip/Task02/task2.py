from itertools import combinations

def links(kind, n):
    nodes = list(range(n))
    if kind == "bus":
        return [(i, i+1) for i in range(n-1)]
    if kind == "ring":
        return [(i, (i+1)%n) for i in range(n)]
    if kind == "star":
        return [("hub", i) for i in nodes]
    if kind == "mesh":
        return list(combinations(nodes, 2))
    raise ValueError(kind)

def connected_after_failure(edges, n, broken):
    seen = {0}
    queue = [0]
    for x in queue:
        for a, b in edges:
            if (a,b) == broken:
                continue
            y = b if a == x else a if b == x else None
            if y is not None and y not in seen:
                seen.add(y)
                queue.append(y)
    return all(i in seen for i in range(n))

for n in (6, 20):
    print("n =", n)
    for kind in ("bus", "ring", "star", "mesh"):
        e = links(kind, n)
        ports = max(sum(1 for a,b in e if x in (a,b))
                    for x in set(sum(e, ())))
        ok = sum(connected_after_failure(e,n,b) for b in e)
        print(f"{kind}: links {len(e)}, max ports {ports}, "
              f"survived {ok}/{len(e)}")
print("Hybrid cost INR:", 5*(60000+2*18000))
