old = 10/30
print(f"Old bus: {old:.3f} Mbps/user")
print("Switched access: 1000 Mbps/port")
print(f"Shared server: {1000/30:.2f} Mbps/user")
print(f"Wi-Fi estimate: {600/30:.2f} Mbps/user")
