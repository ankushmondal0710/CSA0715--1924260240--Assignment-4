copper = 10*80 + 6*60
fiber = 96+420
for name,m in [("Consulting",80),("Pharmacy",96),
               ("AP",60),("Backbone",420)]:
    print(name, "PASS" if m<=90 else "FAIL")
print(f"Copper purchase: {copper*1.1:.1f} m")
print(f"Fiber purchase: {fiber*1.1:.1f} m")
print("Switched segments: 18; VLAN domains: 3")
