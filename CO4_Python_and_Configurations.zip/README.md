# CSA07 Assignment 4
Name: [fill]
Register number: [fill]
OS: [fill]
Python version: [py --version]
Packet Tracer version: [Help > About]

Run each task with `py taskN.py` inside its folder. See procedure.txt for practical steps. output.txt and output.png contain executed Python results, not Packet Tracer proof. Add personally executed .pkt files and screenshots.

Results: T1 bandwidth; T2 topology resilience; T3 cable limits; T4 throughput; T5 VLAN policy model; T6 capacity planning.
