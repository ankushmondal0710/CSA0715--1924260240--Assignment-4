from math import ceil
rows = [("Academic",200,12,600),("Labs",600,13,1300),
        ("Library",100,9,450),("Hostels",300,90,4500),
        ("Auditorium",50,15,750),("DC",100,2,1000)]
for name,ports,aps,peak in rows:
    switches=ceil((ports+aps)*1.5/48)
    print(f"{name}: {switches} switches; peak {peak} Mbps")
print("Total switches:",sum(ceil((p+a)*1.5/48) for _,p,a,_ in rows))
print("Total peak Mbps:",sum(r[3] for r in rows))
print("APs:",sum(r[2] for r in rows))
