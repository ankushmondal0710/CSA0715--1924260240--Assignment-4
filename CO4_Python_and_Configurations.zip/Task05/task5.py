print("802.1Q tag: 4 bytes")
print("Tagged frame:",1518+4,"bytes")
print("User broadcast domains: 1 -> 3")
for dst in ("Office","CCTV","External"):
    print("Guest ->",dst, "ALLOW" if dst=="External" else "DENY")
