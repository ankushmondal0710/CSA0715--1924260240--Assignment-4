# CSA07 CO2 Assignment 2 — working pack

This pack contains Python source files, IOS configuration templates, reference output images and a step-by-step report.

## Important evidence note
The PNGs are generated reference-output images, not screenshots captured from your computer. The `.pkt` project files and Wireshark `.pcapng` captures must be created by you in Cisco Packet Tracer/Wireshark. Do not represent reference images as live simulation evidence.

## Run Python programs
Install Python 3. Open Command Prompt in the relevant Task folder and run:
`python q2_vlsm.py` (or the matching file name).
Q1/Q2/Q3/Q4/Q5/Q6/Q7 scripts use only Python's standard library. Q4 also prints the table after the C-D link is treated as failed.

## Packet Tracer
Use the report's device placement, cabling, addressing and CLI steps. Save each completed simulation as `TaskXX_<topic>.pkt`. Use `show ip route`, `show ip protocols`, `ping`, `tracert` and `show ip interface brief` as applicable. Capture your own screenshots.

## GitHub
Create repository `CSA07-<RegisterNumber>-Assignment2`. Add this folder, then commit task folders separately. Do not fabricate earlier commit dates/history. Add your name, register number, OS, Python version and Packet Tracer version to this README before submission.
