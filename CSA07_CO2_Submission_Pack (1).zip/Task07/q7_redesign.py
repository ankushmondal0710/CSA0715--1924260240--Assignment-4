"""Q7: Address-capacity check for the redesigned campus."""
import ipaddress
original=[
    ipaddress.ip_network("192.168.10.0/25"),
    ipaddress.ip_network("192.168.10.128/26"),
    ipaddress.ip_network("192.168.10.192/27"),
    ipaddress.ip_network("192.168.10.224/30"),
]
redesigned=ipaddress.ip_network("192.168.10.0/23")
hostel=ipaddress.ip_network("192.168.11.0/26")
print("Original allocation:", ", ".join(map(str,original)))
print("Original free tail:", "192.168.10.228 - 192.168.10.255 (28 addresses)")
print("Hostel requirement:", "60 usable hosts -> /26 (64 total addresses)")
print("Redesigned parent:", redesigned)
print("New hostel subnet:", hostel)
print("Hostel subnet contained in redesigned parent:", hostel.subnet_of(redesigned))
