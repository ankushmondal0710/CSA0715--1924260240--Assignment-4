"""Q6: IPv6, EUI-64, IPv4 multicast MAC and tunnel overhead."""
import ipaddress
address="2001:0db8:0000:0000:0000:ff00:0042:8329"
print("Compressed IPv6:", ipaddress.ip_address(address).compressed)
mac=[0x00,0x1A,0x2B,0x3C,0x4D,0x5E]
mac[0]^=0x02  # invert universal/local bit
iid=mac[:3]+[0xFF,0xFE]+mac[3:]
print("Modified EUI-64:", ":".join(f"{x:02x}" for x in iid))
print("Interface ID:", f"{iid[0]<<8|iid[1]:04x}:{iid[2]<<8|iid[3]:04x}:"
      f"{iid[4]<<8|iid[5]:04x}:{iid[6]<<8|iid[7]:04x}")
group=ipaddress.IPv4Address("239.1.2.3")
low23=int(group)&0x7fffff
mac_value=0x01005e000000|low23
print("IPv4 multicast MAC:", ":".join(f"{(mac_value>>s)&255:02x}" for s in (40,32,24,16,8,0)))
print("6in4 outer IPv4 header overhead: 20 bytes; 100-byte inner packet becomes 120 bytes (excluding link-layer headers).")
